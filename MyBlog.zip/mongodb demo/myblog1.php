<?php session_start(); 
echo  "<b> Welcome :- " . $_SESSION['username'] . "</b> <hr>";
echo '<a href=search.php > Search </a> <br> <br>';

require "mainclass1.php";
$obj = new mainclass1();
?>

<form action="" method="" >
    Post Title :- <input type="text" name="title" >
    <br> <br>
    Post Content :- <textarea rows="15" cols="50" name="content" >   </textarea>
    <br><br>
    Post Category :- <input type="radio" value="music" name="cat" > Music
    <input type="radio" value="technology" name="cat" > Technology
    <input type="radio" value="sports" name="cat" > Sports
    <br> <br>
    <input type="submit" name="submit" value="submit" > 
</form>
<?php
if(isset($_REQUEST['submit']))
{
   
    $r = $obj->addpostdetails($_SESSION['username'], $_REQUEST['title'], $_REQUEST['content'], $_REQUEST['cat']);
    if($r == 1)
    {
        echo "Post added";
    }
}
?>

<?php
    $r = $obj->fetchpostdetails($_SESSION['username']);
    echo "<br><br> <hr><br> Post Details :- </b> <hr>";
    echo "<table border=1>";
    echo "<th>Post Title </th> <th> Post Content </th> <th> Category</th>";
    foreach($r as $d)
    {
        echo "<tr> <td>" . $d->title. "</td>";
        echo " <td>" . $d->content. "</td>";
        echo " <td>" . $d->cat. "</td>";
        echo " <td> <a href=updatepost.php?id=".$d->_id . "> Update </td>";
        echo " <td> <a href=deletepost.php?id=".$d->_id . "> Delete </td>";
        echo "</tr>";
    }



?>