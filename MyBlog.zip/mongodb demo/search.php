<?php
session_start(); 
echo  "<b> Welcome :- " . $_SESSION['username'] . "</b> <hr>";
require "mainclass1.php";
$obj = new mainclass1();

?>

<form action="" method="" >
Post Category :- <input type="radio" value="music" name="cat" > Music
    <input type="radio" value="technology" name="cat" > Technology
    <input type="radio" value="sports" name="cat" > Sports
    <br> <br>
    <input type="submit" name="submit" value="submit" > 
   
</form>
<?php
if(isset($_REQUEST['submit']))
{
   
    $r = $obj->searchpost($_REQUEST['cat']);
   
    
    echo "<br><br> <hr><br> Post Details :- </b> <hr>";
    echo "<table border=1>";
    echo "<th>Post Title </th> <th> Post Content </th> <th> Category</th>";
    foreach($r as $d)
    {
        echo "<tr> <td>" . $d->title. "</td>";
        echo " <td>" . $d->content. "</td>";
        echo " <td>" . $d->cat. "</td>";
        echo " <td> <a href=updatepost.php?id=".$d->_id . "> Update </td>";
        echo " <td> <a href=deletepost.php?id=".$d->_id . "> Delete </td>";
        echo "</tr>";
    }
   
}

?>