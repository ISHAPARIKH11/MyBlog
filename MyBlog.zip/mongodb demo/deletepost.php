<?php
require "mainclass1.php";
$obj = new mainclass1();
$r = $obj->deletepostdetailsbyid($_GET['id']);
if($r)
{
    header('location:myblog1.php');
}
?>