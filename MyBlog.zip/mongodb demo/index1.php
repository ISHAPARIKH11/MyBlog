<html>
    <a href="login1.php" > login </a>
    <br>
    <br\>
    <a href="reg1.php" > Registration </a>
</html>