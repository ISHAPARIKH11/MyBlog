<form method="post" action="#" >
    Username:- <input type="text" name="username" > <br>    
    Password:- <input type="text" name="password" > <br>    
    ContactNo:- <input type="text" name="contactno" > <br>  
    <hr> Interested in  </hr>
    Music <input type="checkbox" name="cat[]" value="music" >
    Technology <input type="checkbox" name="cat[]" value="tech" >
    Entertainment  <input type="checkbox" name="cat[]" value="ent" >
    Sports <input type="checkbox" name="cat[]" value="sports" >
    <input type="submit" name="submit" value="Register" > <br>    
</form>
<?php
if(isset($_REQUEST['submit']))
{
    require "mainclass1.php";
    $obj = new mainclass1();
    $cat = implode(",", $_REQUEST['cat']);
    $r = $obj->reg_userdetails($_REQUEST['username'], $_REQUEST['password'], $_REQUEST['contactno'], $cat);
  
    if($r == 1)
    {
        header('location:login1.php');
    }
}



?>