<?php
class mainclass1
{
    private $con;
    function __construct()
    {
        try{
            $this->con = new MongoDB\Driver\Manager("mongodb://localhost:27017");
           
        }
        catch(MongoDB\Driver\Exception\Exception $e)        
        {
                echo $e->getMessage();
        }
    }
    function reg_userdetails($a, $b, $c, $d)
    {
        $bulk = new MongoDB\Driver\BulkWrite;
        $bulk->insert(array('username' => $a, 'password' => $b, 'contactno' => $c, 'category' => $d));
        $r = $this->con->executeBulkWrite("blog.usermaster", $bulk);
        return $r->getInsertedCount();

    }  
    function checkuser($a, $b) 
    {   

        $filter = array('username' => $a, 'password' => $b);
        $qry = new  MongoDB\Driver\Query($filter);
        $r = $this->con->executeQuery('blog.usermaster',$qry );
        return count($r->toArray());    
       
    }
    function addpostdetails($a, $b, $c, $d)
    {
        $bulk = new MongoDB\Driver\BulkWrite;
        $bulk->insert(array('username' => $a, 'title' => $b, 'content' => $c, 'cat' => $d));
        $r = $this->con->executeBulkWrite("blog.postdetails", $bulk);
        return $r->getInsertedCount();
    }
    function fetchpostdetails($a)
    {
        $filter = array('username' => $a);
        $qry = new MongoDB\Driver\Query($filter);
        $r = $this->con->executeQuery("blog.postdetails", $qry);
        return $r;
    }
    function fetchpostdetailsbyid($a)
    {
        $filter = array('_id' => new MongoDB\BSON\ObjectID($a));
        $qry = new MongoDB\Driver\Query($filter);
        $r = $this->con->executeQuery("blog.postdetails", $qry);
        return $r;
    }
    function updatepost($a, $b, $c)
    {
        $bulk = new MongoDB\Driver\BulkWrite;
        $arg1 = array('_id' => new MongoDB\BSON\ObjectID($a));
        $arg2 = array('$set' => array('title' => $b, 'content' => $c));
        $bulk->update($arg1, $arg2);
        $r = $this->con->executeBulkWrite("blog.postdetails", $bulk);
        return 1;
    }
    function deletepostdetailsbyid($a)
    {
        $bulk = new MongoDB\Driver\BulkWrite;
        $arg1 = array('_id' => new MongoDB\BSON\ObjectID($a));
        $bulk->delete($arg1);
        $r = $this->con->executeBulkWrite("blog.postdetails", $bulk);
        return 1;
    }
    function searchpost($a)
    {
        $filter = array('cat' => $a);
        $qry = new MongoDB\Driver\Query($filter);
        $r = $this->con->executeQuery("blog.postdetails", $qry);
        return $r;
    }
}

//$obj = new mainclass1();
//var_dump($);
?>