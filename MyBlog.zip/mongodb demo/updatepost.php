<?php
session_start();
echo "welcome" . $_SESSION['username'];
require "mainclass1.php";
$obj = new mainclass1();
$r = $obj->fetchpostdetailsbyid($_GET['id']);
foreach($r as $r1)
{ 
?>

<form action="" method="" >
    Post Title :- <input type="text" name="title" value=<?php echo $r1->title; ?> >
    <br> <br>
    Post Content :- <textarea rows="15" cols="50" name="content" ><?php echo $r1->content; ?>    </textarea>
    <br><br> 
    Post Category :- <input type="radio" value="music" name="cat" <?php if(strcmp($r1->cat, "music") == 0) echo 'checked';  ?>  > Music
    <input type="radio" value="technology" name="cat" > Technology
    <input type="radio" value="sports" name="cat" > Sports
    <br> <br>
    <input type="submit" name="submit" value="update" > 
    <input type="hidden" name="id" value=<?php echo $r1->_id; ?> >
</form>
<?php
}
if(isset($_REQUEST['submit']))
{
    $r = $obj->updatepost($_REQUEST['id'], $_REQUEST['title'], $_REQUEST['content']);
    if($r)
    {
        header('location:myblog1.php');
    }


}


?>