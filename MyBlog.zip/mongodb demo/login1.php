<?php session_start(); ?>
<form method="post" action="#" >
    Username:- <input type="text" name="username" > <br>    
    Password:- <input type="text" name="password" > <br>    
    
    <input type="submit" name="submit" value="Login" > <br>    
</form>
<?php
if(isset($_REQUEST['submit']))
{
    require "mainclass1.php";
    $obj = new mainclass1();
    $r = $obj->checkuser($_REQUEST['username'], $_REQUEST['password']);
    if($r == 1)
    {
        $_SESSION['username'] = $_REQUEST['username'];
        header('location:myblog1.php');
    }
}



?>